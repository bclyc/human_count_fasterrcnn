/*
* Copyright(C) 2010,Custom Co., Ltd 
*    FileName: playback.h
* Description: 
*     Version: 1.0
*      Author: panyadong
* Create Date: 2012-2-21
* Modification History��
*/
#ifndef _TOOL_H_
#define _TOOL_H_
#include "public.h"

int Demo_DVRIPByResolveSvr();

#endif

